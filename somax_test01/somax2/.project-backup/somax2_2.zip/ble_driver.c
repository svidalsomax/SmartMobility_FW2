/*
 * ble_driver.c
 *
 *  Author: MWF
 */ 

#include "ble_driver.h"

#define MAX_MESSAGE_LENGTH 64	// Cambiar tambien USART_0_BUFFER_SIZE en driver_init.c
#define TIME_TO_DELAY 20

static struct io_descriptor *ble_io;


static void tx_cb_USART_0(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
	//usb_serial_write("Tx completed\n", strlen("Tx completed\n"));
}

static void rx_cb_USART_0(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
	//usb_serial_write("Rx completed\n", strlen("Rx completed\n"));
}

int ble_init(void)
{
	usart_async_register_callback(&USART_0, USART_ASYNC_TXC_CB, tx_cb_USART_0);
	usart_async_register_callback(&USART_0, USART_ASYNC_RXC_CB, rx_cb_USART_0);
	//usart_async_register_callback(&USART_0, USART_ASYNC_ERROR_CB, err_cb);
	usart_async_get_io_descriptor(&USART_0, &ble_io);
	usart_async_enable(&USART_0);
	delay_ms(TIME_TO_DELAY);
	
	return 0;
}

void ble_send(char* command)
{
	char at_cmd[MAX_MESSAGE_LENGTH] = {0};
	strcpy(at_cmd, "");
	strcat(at_cmd, command);
	io_write(ble_io, (uint8_t *)at_cmd, strlen(at_cmd));
}

void ble_send_and_receive(char* command, char* response)
{
	char at_cmd[MAX_MESSAGE_LENGTH] = {0};
	strcpy(at_cmd, "");
	strcat(at_cmd, command);
	io_write(ble_io, (uint8_t *)at_cmd, strlen(at_cmd));
	delay_ms(TIME_TO_DELAY);
	io_read(ble_io, response, MAX_MESSAGE_LENGTH);
	delay_ms(TIME_TO_DELAY);
}


/******************************************************************************
**      FUNCIONES SOMAX
******************************************************************************/

void ble_process(Ble *ble){
	//strcat((*ble).rxBuffer_, "hola"); //rxBuffer deber�a leer lo del UART.
	char buffer[MAX_MESSAGE_LENGTH];
	switch ((*ble).bleState_) //definir el blestate_
	{
		case BLE_BEGIN:
		{
			strcpy(buffer, "AT");
			//if timer
			ble_retry(BLE_RENEW, ble, buffer);
			break;
		}
		case BLE_RENEW:
		{
			strcpy(buffer, "AT+RENEW");
			//strcpy(buffer, "AT");
			//if timer
			ble_retry(BLE_RENEW, ble, buffer);
			break;
		}
		case BLE_ROLE:
		{
			strcpy(buffer, "AT+ROLE1");
			//if timer
			ble_retry(BLE_IMME, ble, buffer);
		}
		case BLE_IMME:
		{
			strcpy(buffer, "AT+IMME1");
			//if timer
			ble_retry(BLE_IMME, ble, buffer);
		}
		case BLE_RESET:
		{
			strcpy(buffer, "AT+RESET");
			// if timer
			ble->tryCounter_ = (ble->tryCounter_ == 0) ? ble->tryCounter_+1:ble->tryCounter_ ; 
			ble_retry(BLE_PROCESS, ble, buffer);
		}
		case BLE_PROCESS: 
		{
			if(!ble->state_){
				strcpy(ble->txBuffer_,"AT+DISI?");
				ble->state_=1;
			}
			else{
				size_t size = strlen(ble->rxBuffer_); 

				if(size >= 8 && strcmp(ble->rxBuffer_ + (size - 8), "OK+DISCE") == 0){
					//funcion parse de ble->rxBuffer_
					ble->rxBuffer_[0] ='\0';
					ble->state_ = 0; 
				}

				/*if (millis() - scanTime_ > 3500)
                	state_ = 0;*/
			}
			break;
			
		}
		default:
		{
			break;
		}
	}
	if(!(ble->txBuffer_[0]=='\0')){
		//printf(ble->txBuffer_);
		ble->scanTime_ =0;
	}

	if(ble->rxBuffer_[0] == '\0' && !ble->scanTime_){
		//ble->scanTime_ = millis();
	}
}


/*
// ---- Se a�aden los escaneos del Ble al vector beaconScan y se borra la info de scan del Ble
*/
ble_Scan ble_getScan(Ble *ble) {
	ble_process(ble);
	ble_Scan beaconScan = (*ble).scan_;
	clean_ble_Scan(&(*ble).scan_);
	return beaconScan;
}

//Hace cero todos los par�metros del scan, incluyendo el beaconVector
void clean_ble_Scan(ble_Scan* scan){
	scan->scanTime_ = 0;
	for (int i = 0; i < 100; i++) {
		scan->beaconVector[i].mac_ = 0;
		scan->beaconVector[i].rssi_ = 0;
	}
}


void ble_retry(bleStatus state, Ble *ble, char *buffer){
	(*ble).bleState_ = state;
	ble_send_and_receive(buffer, ble->response_);
	//command para enviar comando por uart
}

void ble_set_timer(unsigned long t, Ble *ble){
	(*ble).timer_ = t;
	//(*ble).time =  ;
}