/* 
 * ble_driver.h
 *
 *  Author: MWF
 */ 


#ifndef BLE_DRIVER_H_
#define BLE_DRIVER_H_

/******************************************************************************
**      INCLUDES
******************************************************************************/
#include <atmel_start_pins.h>
#include <hal_gpio.h>
#include <hal_usart_async.h>
#include <driver_init.h>
#include <string.h>

/******************************************************************************
**      VARIABLES SOMAX - BLE
******************************************************************************/

typedef enum {
	BLE_BEGIN,
	BLE_RENEW,
	BLE_ROLE,
	BLE_IMME,
	BLE_RESET,
	BLE_PROCESS,
}bleStatus;

//Beacon - used to create Beacon Vector initialized and used throght ble_Scan struct.
typedef struct {
	unsigned long long mac_;
	int rssi_;
} Beacon;

//ble_Scan - used for ...
typedef struct{
	unsigned long scanTime_;
	Beacon beaconVector[100];
}ble_Scan;


typedef struct{
	char txBuffer_[64];
	char rxBuffer_[64];
	bleStatus bleState_;
	unsigned long timer_;
	unsigned long time_;
	int tryCounter_;
	char state_;
	bool role_ ;
	int scanTime_;
	ble_Scan scan_;
	char response_[64];
}Ble;



/******************************************************************************
**      FUNCIONES LANEK
******************************************************************************/


int ble_init(void);
void ble_send(char* command);
void ble_send_and_receive(char* command, char* response);

/******************************************************************************
**    FUNCIONES SOMAX
******************************************************************************/


void ble_process(Ble *ble);




/*
// ---- Se a�aden los escaneos del Ble al vector beaconScan y se borra la info de scan del Ble
*/
ble_Scan ble_getSecan(Ble *ble);

/*
// ---- Limpia el vector de beacons y el escaneo
*/
void clean_ble_Scan(ble_Scan* scan);
/*
// ---- Env�a comando AT del ble definido antes
*/
void ble_retry(bleStatus state, Ble *ble, char *buffer);


void ble_set_timer(unsigned long t, Ble *ble);

#endif /* BLE_DRIVER_H_ */